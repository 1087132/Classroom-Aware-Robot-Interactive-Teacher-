"""Content Manager persistence, authentication and per-screen publishing."""
import copy
import unittest
from unittest.mock import patch

import test_pi_access as fixture
from backend import content

class ContentTests(unittest.TestCase):
    def setUp(self):
        fixture.AppTests.setUp(self)
        content._heartbeat.update(received_at=0, screens=[])

    tearDown = fixture.AppTests.tearDown
    login = fixture.AppTests.login
    public_client = fixture.AppTests.public_client

    def settings(self):
        return self.client.get("/api/content").json()

    def post(self, settings):
        return self.client.post("/api/content", json=settings, headers=fixture.HEADERS)

    def test_new_page_and_apis_require_teacher_login(self):
        self.assertEqual(self.client.get("/content", follow_redirects=False).status_code, 302)
        for path in ("/api/content", "/api/content/status"):
            self.assertEqual(self.client.get(path).status_code, 401)
        self.assertEqual(self.post({}).status_code, 401)
        self.login()
        self.assertIn("Content Manager", self.client.get("/content").text)
        self.assertEqual(self.client.get("/api/content").headers["cache-control"], "no-store")

    def test_lan_cannot_read_or_publish_even_with_teacher_cookie(self):
        token = self.login()
        guest = self.public_client()
        guest.cookies.set(fixture.auth.COOKIE_NAME, token)
        for path in ("/content", "/api/content", "/api/content/status", "/api/display-config"):
            self.assertEqual(guest.get(path).status_code, 403, path)
        for path in ("/api/content", "/api/content/refresh", "/api/display-status"):
            self.assertEqual(guest.post(path, json={}, headers=fixture.HEADERS).status_code, 403, path)
        guest.close()

    def test_write_header_and_origin_are_checked(self):
        self.login()
        settings = self.settings()
        self.assertEqual(self.client.post("/api/content", json=settings).status_code, 403)
        self.assertEqual(self.client.post("/api/content", json=settings,
            headers={**fixture.HEADERS, "Origin": "https://untrusted.example"}).status_code, 403)

    def test_defaults_preserve_robot_and_lesson(self):
        self.login()
        settings = self.settings()
        self.assertEqual(settings["screens"], content.DEFAULTS)
        self.assertFalse(settings["launcher"]["online"])

    def test_two_links_persist_and_local_player_sees_them(self):
        self.login()
        settings = self.settings()
        for screen, url in zip(settings["screens"], ("https://example.org/lesson?a=1&b=2", "http://192.168.1.20:8080/slides")):
            screen.update(mode="website", url=url)
        saved = self.post(settings)
        self.assertEqual(saved.status_code, 200, saved.text)
        self.assertEqual(saved.json()["revision"], 2)
        # Read from a new SQLite connection, not an in-memory configuration.
        self.assertEqual(content.get_settings()["screens"], saved.json()["screens"])
        self.client.cookies.clear()
        player = self.client.get("/api/display-config")
        self.assertEqual(player.status_code, 200)
        self.assertEqual(player.json()["screens"], saved.json()["screens"])
        self.assertNotIn("updated_by", player.json())

    def test_only_changed_target_gets_a_new_version(self):
        self.login()
        settings = self.settings()
        settings["screens"][0].update(mode="website", url="https://example.org/")
        saved = self.post(settings).json()
        self.assertEqual([s["version"] for s in saved["screens"]], [2, 1])
        saved["screens"][1]["label"] = "Side display"
        renamed = self.post(saved).json()
        self.assertEqual([s["version"] for s in renamed["screens"]], [2, 1])
        self.assertEqual(renamed["revision"], 3)
        self.assertEqual(self.post(renamed).json()["revision"], 3)

    def test_refresh_only_bumps_selected_screen(self):
        self.login()
        settings = self.settings()
        response = self.client.post("/api/content/refresh",
            json={"revision": settings["revision"], "screen": 2}, headers=fixture.HEADERS)
        self.assertEqual(response.status_code, 200)
        self.assertEqual([s["version"] for s in response.json()["screens"]], [1, 2])
        self.assertEqual(response.json()["screens"][1]["mode"], "projector")

    def test_conflict_preserves_latest_published_settings(self):
        self.login()
        old = self.settings()
        changed = copy.deepcopy(old)
        changed["screens"][0].update(mode="website", url="https://example.org/")
        saved = self.post(changed).json()
        self.assertEqual(self.post(old).status_code, 409)
        response = self.client.post("/api/content/refresh",
            json={"revision": old["revision"], "screen": 1}, headers=fixture.HEADERS)
        self.assertEqual(response.status_code, 409)
        self.assertEqual(self.settings()["screens"], saved["screens"])

    def test_can_restore_builtin_modes(self):
        self.login()
        settings = self.settings()
        settings["screens"][0].update(mode="website", url="https://example.org/")
        saved = self.post(settings).json()
        saved["screens"][0]["mode"] = "robot"
        restored = self.post(saved).json()
        self.assertEqual(restored["screens"][0]["mode"], "robot")
        self.assertEqual(restored["screens"][0]["url"], "")
        self.assertEqual(restored["screens"][1], content.DEFAULTS[1])

    def test_invalid_urls_do_not_change_published_content(self):
        self.login()
        for url in ("javascript:alert(1)", "file:///etc/passwd", "ftp://example.org",
                    "https://user:password@example.org", "https://", "https://example.org:99999",
                    "https://example.org:0", "https://exa mple.org", "https://example.org/\nnext",
                    "http://localhost:8000/teacher", "http://sub.localhost./teacher",
                    "http://127.0.0.1", "http://[::1]", "http://[::ffff:127.0.0.1]",
                    "http://0.0.0.0", "http://2130706433", "http://0x7f000001", "http://127.1",
                    "https://example.org\\evil", "https://example.org/" + "a" * 2048):
            with self.subTest(url=url[:80]):
                settings = self.settings()
                settings["screens"][0].update(mode="website", url=url)
                self.assertEqual(self.post(settings).status_code, 400)
                self.assertEqual(content.get_settings()["revision"], 1)

    def test_malformed_inputs_are_rejected(self):
        self.login()
        for field, value in (("id", True), ("id", 2), ("label", ""), ("label", "a" * 81),
                             ("mode", "unknown"), ("mode", None)):
            with self.subTest(field=field, value=value):
                settings = self.settings()
                settings["screens"][0][field] = value
                self.assertEqual(self.post(settings).status_code, 400)
        for body in ({"revision": True, "screens": content.DEFAULTS}, {"revision": 1, "screens": []}, []):
            self.assertEqual(self.post(body).status_code, 400)
        for body in ('{"bad"', '"string"', " " * 12001):
            self.assertEqual(self.client.post("/api/content", content=body, headers=fixture.HEADERS).status_code, 400)

    def test_status_requires_local_client_and_write_header_and_expires(self):
        body = {"screens": [
            {"id": 1, "version": 1, "status": "running", "output": "HDMI-A-1"},
            {"id": 2, "version": 1, "status": "starting", "output": "HDMI-A-2"}]}
        self.assertEqual(self.client.post("/api/display-status", json=body).status_code, 403)
        self.assertEqual(self.client.post("/api/display-status", json=body, headers=fixture.HEADERS).status_code, 200)
        self.login()
        status = self.client.get("/api/content/status").json()
        self.assertTrue(status["launcher"]["online"])
        self.assertEqual(status["launcher"]["screens"][1]["status"], "starting")
        with patch.object(content.time, "time", return_value=status["launcher"]["received_at"] + 16):
            self.assertFalse(content.status()["online"])
        body["screens"][0]["version"] = -1
        self.assertEqual(self.client.post("/api/display-status", json=body, headers=fixture.HEADERS).status_code, 400)

if __name__ == "__main__":
    unittest.main()

