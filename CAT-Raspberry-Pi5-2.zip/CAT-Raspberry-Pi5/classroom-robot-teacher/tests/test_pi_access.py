"""Access boundaries and the existing lesson flow, without camera/model hardware."""
import copy
import importlib.util
import os
from pathlib import Path
import sys
import tempfile
import time
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
temporary = tempfile.TemporaryDirectory()
os.environ["CAT_DATA_DIR"] = temporary.name
from fastapi.testclient import TestClient
from starlette.websockets import WebSocketDisconnect
from backend import auth, database as db, main
from backend.access import public_event
from backend.lesson_engine import LessonEngine

PASSWORD = "Private test passphrase 2026!"
HEADERS = {"Origin": "http://127.0.0.1:8000", "X-CAT-Request": "1"}


class AppTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir=temporary.name)
        db.DB_PATH = Path(self.temp.name) / "cat.db"
        main.LESSONS_DIR = Path(self.temp.name) / "lessons"
        db.init_db()
        auth._sessions.clear(); auth._students.clear(); auth._attempts.clear()
        auth.set_password("teacher", PASSWORD)
        main.engine = LessonEngine()
        main.schedules.clear()
        main.manager.clients.clear()
        self.client = TestClient(main.app, base_url="http://127.0.0.1:8000", client=("127.0.0.1", 5000))
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.temp.cleanup()

    def login(self):
        response = self.client.post("/api/auth/login", json={"username": "teacher", "password": PASSWORD}, headers=HEADERS)
        self.assertEqual(response.status_code, 200, response.text)
        return self.client.cookies.get(auth.COOKIE_NAME)

    def start_lesson(self):
        self.login()
        lesson_id = db.list_lessons()[0]["id"]
        response = self.client.post("/api/session/start", json={"lesson_id": lesson_id}, headers=HEADERS)
        self.assertEqual(response.status_code, 200, response.text)

    def public_client(self):
        return TestClient(main.app, base_url="http://127.0.0.1:8000", client=("192.168.1.90", 5001))

    def test_pages_and_health(self):
        for path in ("/student", "/robot", "/projector", "/login"):
            self.assertEqual(self.client.get(path).status_code, 200, path)
        for path in ("/teacher", "/tracking", "/account"):
            self.assertEqual(self.client.get(path, follow_redirects=False).status_code, 302, path)
        self.assertEqual(self.client.get("/health").json()["application"], "cat-teacher")

    def test_every_teacher_api_requires_authentication(self):
        tested = 0
        for route in main.app.routes:
            if not route.path.startswith("/api/") or route.path in main.PUBLIC_APIS:
                continue
            path = route.path.replace("{session_id}", "1").replace("{roster_id}", "1").replace("{sch_id}", "1")
            method = next(iter(route.methods & {"GET", "POST"}))
            response = self.client.request(method, path, headers=HEADERS)
            self.assertEqual(response.status_code, 401, path)
            tested += 1
        self.assertGreater(tested, 25)

    def test_default_password_no_longer_works(self):
        self.assertEqual(self.client.post("/api/auth/login", json={"username":"teacher","password":"teach123"}, headers=HEADERS).status_code, 401)
        self.assertNotIn("teach123", self.client.get("/login").text)

    def test_login_requires_same_origin_and_custom_header(self):
        data = {"username":"teacher", "password":PASSWORD}
        self.assertEqual(self.client.post("/api/auth/login", json=data).status_code, 403)
        self.assertEqual(self.client.post("/api/auth/login", json=data, headers={**HEADERS,"Origin":"https://untrusted.example"}).status_code, 403)

    def test_teacher_management_not_exposed_over_plain_lan(self):
        token = self.login()
        guest = self.public_client()
        guest.cookies.set(auth.COOKIE_NAME, token)
        for path in ("/teacher", "/api/analytics", "/api/auth/me"):
            self.assertEqual(guest.get(path).status_code, 403)
        self.assertEqual(guest.get("/student").status_code, 200)
        guest.close()

    def test_private_content_is_not_cacheable(self):
        self.login()
        for path in ("/teacher", "/api/analytics", "/api/state"):
            response = self.client.get(path)
            self.assertEqual(response.headers["cache-control"], "no-store")
            self.assertEqual(response.headers["x-frame-options"], "DENY")

    def test_password_change_revokes_old_session(self):
        token = self.login()
        response = self.client.post("/api/auth/change-password", json={"old_password":PASSWORD,"new_password":"Another private passphrase 2026"}, headers=HEADERS)
        self.assertEqual(response.status_code, 200)
        self.client.cookies.set(auth.COOKIE_NAME,token)
        self.assertEqual(self.client.get("/api/analytics").status_code,401)

    def test_expired_session_rejected(self):
        token = self.login(); auth._sessions[token]["expires"] = time.time()-1
        self.assertEqual(self.client.get("/api/analytics").status_code,401)

    def test_rate_limit_is_applied(self):
        for _ in range(10):
            self.client.post("/api/auth/login", json={"username":"teacher","password":"wrong"}, headers=HEADERS)
        self.assertEqual(self.client.post("/api/auth/login", json={"username":"teacher","password":PASSWORD}, headers=HEADERS).status_code,401)

    def test_teacher_websocket_requires_auth(self):
        for role in ("teacher", "tracking"):
            with self.assertRaises(WebSocketDisconnect):
                with self.client.websocket_connect(f"ws://127.0.0.1:8000/ws?role={role}",headers={"Origin":HEADERS["Origin"]}):
                    pass

    def test_websocket_rejects_other_origins(self):
        self.login()
        with self.assertRaises(WebSocketDisconnect):
            with self.client.websocket_connect("ws://127.0.0.1:8000/ws?role=teacher",headers={"Origin":"https://untrusted.example"}):
                pass

    def test_public_websocket_never_receives_teacher_events(self):
        with self.client.websocket_connect("ws://127.0.0.1:8000/ws?role=projector",headers={"Origin":HEADERS["Origin"]}) as ws:
            for _ in range(3): ws.receive_json()
            self.client.portal.call(main.manager.broadcast, {"type":"speech","transcript":"private transcript"})
            self.client.portal.call(main.manager.broadcast, {"type":"schedule_update","schedules":["private"]})
            self.client.portal.call(main.manager.broadcast, {"type":"expression","expression":"happy"})
            self.assertEqual(ws.receive_json(),{"type":"expression","expression":"happy"})

    def test_teacher_socket_revoked_on_logout(self):
        self.login()
        with self.client.websocket_connect("ws://127.0.0.1:8000/ws?role=teacher",headers={"Origin":HEADERS["Origin"]}) as ws:
            for _ in range(3): ws.receive_json()
            self.client.post("/api/auth/logout",json={},headers=HEADERS)
            self.client.portal.call(main.manager.broadcast,{"type":"expression","expression":"happy"})
            with self.assertRaises(WebSocketDisconnect): ws.receive_json()

    def test_teacher_socket_receives_teacher_events(self):
        self.login()
        with self.client.websocket_connect("ws://127.0.0.1:8000/ws?role=teacher",headers={"Origin":HEADERS["Origin"]}) as ws:
            for _ in range(3): ws.receive_json()
            event={"type":"schedule_update","schedules":[]}
            self.client.portal.call(main.manager.broadcast,event)
            self.assertEqual(ws.receive_json(),event)

    def test_existing_lesson_flow_and_student_binding(self):
        self.start_lesson()
        guest=self.public_client()
        joined=guest.post("/api/join",json={},headers=HEADERS)
        self.assertEqual(joined.status_code,200,joined.text)
        sid=joined.json()["student_id"]
        self.assertEqual([s["id"] for s in guest.get("/api/state").json()["students"]],[sid])
        for _ in range(8):
            if main.engine.status=="question":break
            self.client.post("/api/session/next",json={},headers=HEADERS)
        self.assertEqual(main.engine.status,"question")
        q=main.engine.current_q
        denied=guest.post("/api/answer",json={"student_id":sid+100,"question_id":q["id"],"answer_index":0},headers=HEADERS)
        self.assertEqual(denied.status_code,403)
        result=guest.post("/api/answer",json={"student_id":sid,"question_id":q["id"],"answer_index":0},headers=HEADERS)
        self.assertEqual(result.status_code,200,result.text)
        guest.close()

    def test_uploaded_lesson_uses_writable_data_directory(self):
        self.login()
        lesson=copy.deepcopy(db.get_lesson(db.list_lessons()[0]["id"]))
        lesson["id"]="pi_uploaded_test";lesson["title"]="Uploaded test lesson"
        response=self.client.post("/api/lessons/upload",json={"content":lesson},headers=HEADERS)
        self.assertEqual(response.status_code,200,response.text)
        self.assertTrue((main.LESSONS_DIR/'pi_uploaded_test.json').is_file())

    @unittest.skipUnless(importlib.util.find_spec("qrcode"), "QR dependency is installed by install-pi.sh; unavailable in this test runtime")
    def test_qr(self):
        response=self.client.get('/api/qr.svg')
        self.assertEqual(response.status_code,200)
        self.assertIn('<svg',response.text)


class FilteringTests(unittest.TestCase):
    def test_public_engagement_has_only_scores_intended_for_display(self):
        event={"type":"engagement","class_score":60,"class_attention":70,"alerts":["private"],
               "students":[{"student_id":1,"name":"Student 1","points":50,"attention":10,"history":[1],"roster_id":9}]}
        output=public_event(event,"projector")
        self.assertEqual(output['students'],[{"student_id":1,"name":"Student 1","points":50}])
        self.assertNotIn('alerts',output)
        self.assertEqual(public_event(event,'student',2)['students'],[])

    def test_personal_feedback_requires_matching_student(self):
        event={"type":"answer_feedback","student_id":3,"text":"Individual feedback"}
        self.assertIsNone(public_event(event,'projector',3))
        self.assertIsNone(public_event(event,'student',4))
        self.assertEqual(public_event(event,'student',3),event)

    def test_unknown_events_default_to_private(self):
        self.assertIsNone(public_event({"type":"new_private_feature"},'viewer'))


if __name__ == '__main__':
    unittest.main()
