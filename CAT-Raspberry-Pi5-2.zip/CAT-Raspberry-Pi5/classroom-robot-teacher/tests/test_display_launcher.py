"""Browser lifecycle is mocked: no hardware or real browser is launched."""
import copy
import importlib.util
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from backend import content

spec = importlib.util.spec_from_file_location("cat_launcher", Path(__file__).resolve().parents[1] / "pi/launch-displays.py")
launcher = importlib.util.module_from_spec(spec)
spec.loader.exec_module(launcher)

class LauncherTests(unittest.TestCase):
    def setUp(self):
        self.processes = []
        def spawn(*args, **kwargs):
            process = MagicMock()
            process.pid = 90000 + len(self.processes)
            process.poll.return_value = None
            self.processes.append(process)
            return process
        self.spawn = patch.object(launcher.subprocess, "Popen", side_effect=spawn).start()
        self.stop = patch.object(launcher, "stop_browser").start()
        self.clock = patch.object(launcher.time, "monotonic", return_value=100).start()
        self.addCleanup(patch.stopall)
        self.displays = [launcher.Display(i, f"HDMI-A-{i}", "/usr/bin/chromium", Path("/tmp/cat-test")) for i in (1, 2)]
        self.screens = copy.deepcopy(content.DEFAULTS)

    def apply(self):
        for display, screen in zip(self.displays, self.screens):
            display.apply(screen)

    def test_default_targets_profiles_and_process_isolation(self):
        self.apply()
        self.assertEqual(self.spawn.call_count, 2)
        args1, args2 = [call.args[0] for call in self.spawn.call_args_list]
        self.assertIn("--app=http://127.0.0.1:8000/robot?display=1", args1)
        self.assertIn("--app=http://127.0.0.1:8000/projector?display=1", args2)
        self.assertIn("--class=cat-teacher-screen-1", args1)
        self.assertIn("--user-data-dir=/tmp/cat-test/screen-2", args2)
        self.assertTrue(all(call.kwargs["start_new_session"] for call in self.spawn.call_args_list))

    def test_unchanged_configuration_or_label_does_not_restart(self):
        self.apply()
        self.screens[0]["label"] = "New name"
        self.apply()
        self.assertEqual(self.spawn.call_count, 2)
        self.stop.assert_not_called()

    def test_publishing_new_link_restarts_only_its_screen(self):
        self.apply()
        first, second = self.processes
        self.screens[1].update(mode="website", url="https://example.org/lesson?a=1&b=2", version=2)
        self.apply()
        self.assertEqual(self.spawn.call_count, 3)
        self.stop.assert_called_once_with(second)
        self.assertIs(self.displays[0].process, first)
        self.assertIn("--app=https://example.org/lesson?a=1&b=2", self.spawn.call_args.args[0])

    def test_refresh_version_restarts_even_if_url_is_unchanged(self):
        self.apply()
        first = self.processes[0]
        self.screens[0]["version"] += 1
        self.apply()
        self.stop.assert_called_once_with(first)
        self.assertEqual(self.spawn.call_count, 3)

    def test_exited_browser_is_restarted_after_retry_delay(self):
        self.apply()
        second = self.processes[1]
        second.poll.return_value = 1
        self.assertEqual(self.displays[1].report()["status"], "error")
        self.apply()
        self.assertEqual(self.spawn.call_count, 2)
        self.clock.return_value = 111
        self.apply()
        self.stop.assert_called_once_with(second)
        self.assertEqual(self.spawn.call_count, 3)

    def test_start_failure_reports_error_and_retries(self):
        self.spawn.side_effect = OSError("not executable")
        self.displays[0].apply(self.screens[0])
        report = self.displays[0].report()
        self.assertEqual(report["status"], "error")
        self.assertIn("not executable", report["message"])
        self.displays[0].apply(self.screens[0])
        self.assertEqual(self.spawn.call_count, 1)

    def test_status_distinguishes_starting_running_and_stopped(self):
        self.apply()
        self.assertEqual(self.displays[0].report()["status"], "starting")
        self.clock.return_value = 103
        self.assertEqual(self.displays[0].report()["status"], "running")
        self.assertEqual(self.displays[0].report(stopped=True)["status"], "stopped")

    def test_second_launcher_cannot_overwrite_owner_lock(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "launcher.lock"
            first = launcher.acquire_lock(path)
            try:
                owner = path.read_text()
                with self.assertRaises(SystemExit):
                    launcher.acquire_lock(path)
                self.assertEqual(path.read_text(), owner)
            finally:
                first.close()

if __name__ == "__main__":
    unittest.main()

