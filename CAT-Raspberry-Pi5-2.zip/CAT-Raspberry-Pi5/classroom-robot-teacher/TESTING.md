# Verification of the Raspberry Pi adaptation

Automated run: **39 passed, 1 skipped**, using Python 3.12 with FastAPI and
Starlette's in-process HTTP/WebSocket test client.

Covered: all teacher API permissions; protected pages; private account login;
cross-origin/write-request rejection; teacher access over local/tunneled versus
direct LAN connections; session expiry and password-change revocation; response
cache headers; authenticated teacher WebSockets; rejection of foreign origins;
teacher/public event separation; WebSocket closure after logout; existing lesson
startup; student join/answer flow with browser binding; writable lesson uploads;
public engagement summaries and individual feedback filtering.

Content Manager checks cover authentication and LAN restrictions, default views,
two different saved links, SQLite persistence, input validation, request
validation, publish conflicts, independent screen versions, restoration of CAT
views, reload actions, local launcher access and expiring status reports.

Launcher tests use mocked browser processes to verify independent profiles,
unchanged screens staying open, per-screen updates and reloads, restart delay
after a browser exits, start failure reporting, and launcher lock ownership.
They do not launch Chromium or verify external website loading.

The QR SVG test is skipped when `qrcode` is absent. That package was unavailable
in the build runtime and could not be downloaded there; `install-pi.sh` installs
and checks the Raspberry Pi OS `python3-qrcode` package before starting the app.

Python compilation, shell syntax, shared and Content Manager JavaScript syntax,
and inline JavaScript syntax in all nine frontend pages passed.

Not tested here: a real Pi 5, systemd execution, ARM package installation,
physical HDMI placement, boot/login autostart, browser rendering, QR generation,
camera access, speech/audio, neural models, or sustained classroom operation.
The build environment cannot start Chromium, so no visual or browser end-to-end
verification is claimed. These checks are application tests, not a full audit.

Run the tests from the project directory in an environment with the core
requirements plus `httpx`:

```bash
python -m unittest discover -s tests -v
```
