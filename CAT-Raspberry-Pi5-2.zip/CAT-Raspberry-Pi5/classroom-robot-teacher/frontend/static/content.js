/* Teacher-only editing; no display URLs are embedded or fetched by the server. */
(() => {
  const el = id => document.getElementById(id);
  const modeNames = {robot: "CAT robot face", projector: "CAT lesson / projector", website: "Website link"};
  let saved = null;
  let busy = false;
  let statusBusy = false;

  function drafts() {
    return [1, 2].map(id => ({id, label: el("label" + id).value.trim(),
      mode: el("mode" + id).value,
      url: el("mode" + id).value === "website" ? el("url" + id).value.trim() : ""}));
  }
  function dirty() {
    return saved && drafts().some((draft, i) =>
      ["label", "mode", "url"].some(key => draft[key] !== saved.screens[i][key]));
  }
  function message(text, error = false) {
    el("message").textContent = text;
    el("message").classList.toggle("message-error", error);
  }
  function updateDraft() {
    for (const id of [1, 2]) {
      const mode = el("mode" + id).value;
      const website = mode === "website";
      el("urlField" + id).hidden = !website;
      el("url" + id).required = website;
      el("url" + id).disabled = !website;
      el("builtin" + id).hidden = website;
      el("builtin" + id).textContent = mode === "robot" ?
        "The animated CAT robot face will appear on this screen." :
        "This screen will show your current CAT lesson, questions and class results.";
    }
    el("draftStatus").textContent = dirty() ? "Unpublished changes" : "All changes saved";
    el("discard").disabled = busy || !dirty();
    el("publish").disabled = busy || !saved;
  }
  function showSettings(data, fillInputs = true) {
    saved = data;
    for (const screen of data.screens) {
      const id = screen.id;
      if (fillInputs) {
        el("label" + id).value = screen.label;
        el("mode" + id).value = screen.mode;
        el("url" + id).value = screen.url;
      }
      el("saved" + id).textContent = "Saved: " + (screen.mode === "website" ? screen.url : modeNames[screen.mode]);
    }
    el("savedAt").textContent = data.updated_at ?
      "Last saved " + new Date(data.updated_at * 1000).toLocaleString() : "Default CAT views";
    el("conflict").hidden = true;
    updateDraft();
    showStatus(data);
  }
  function showStatus(data) {
    const online = data.launcher.online;
    el("launcherStatus").textContent = online ? "Display launcher connected" : "Display launcher offline";
    el("launcherStatus").className = "badge " + (online ? "badge-green" : "badge-yellow");
    for (const item of data.screens) {
      const live = data.launcher.screens.find(screen => screen.id === item.id);
      const node = el("state" + item.id);
      let text = "Waiting for display launcher";
      let color = "badge-yellow";
      if (online && live) {
        if (live.status === "error") { text = live.message || "Browser could not start"; color = "badge-red"; }
        else if (live.status === "stopped") text = "Browser stopped";
        else if (live.version !== item.version || live.status === "starting") text = "Applying saved content…";
        else if (live.status === "running") { text = "Browser running · saved content applied"; color = "badge-green"; }
      }
      node.textContent = text;
      node.className = "screen-state badge " + color;
      if (live && live.output) el("output" + item.id).textContent = live.output;
    }
    if (saved && data.revision !== saved.revision) el("conflict").hidden = false;
  }
  function setBusy(value) {
    busy = value;
    el("contentFields").disabled = value || !saved;
    el("reloadSaved").disabled = value;
    updateDraft();
  }
  async function loadSettings() {
    setBusy(true);
    el("retryLoad").hidden = true;
    try {
      showSettings(await api("/api/content"));
      message("");
    } catch (error) {
      message("Could not load saved settings. " + error.message, true);
      el("retryLoad").hidden = false;
    } finally { setBusy(false); }
  }

  el("contentForm").addEventListener("input", updateDraft);
  el("contentForm").addEventListener("change", updateDraft);
  el("contentForm").addEventListener("submit", async event => {
    event.preventDefault();
    if (busy || !saved) return;
    const body = {revision: saved.revision, screens: drafts()};
    setBusy(true);
    try {
      showSettings(await api("/api/content", body));
      message("Saved. The display launcher will apply changed links when it is connected.");
    } catch (error) { message(error.message, true); await pollStatus(true); }
    finally { setBusy(false); }
  });
  el("discard").onclick = () => {
    if (saved) { showSettings(saved); message("Unpublished edits discarded."); }
  };
  el("reloadSaved").onclick = () => {
    if (!dirty() || window.confirm("Discard your unpublished edits and load the latest saved settings?")) loadSettings();
  };
  el("retryLoad").onclick = loadSettings;
  for (const button of document.querySelectorAll("[data-default]")) {
    button.onclick = () => {
      const id = Number(button.dataset.default);
      el("mode" + id).value = id === 1 ? "robot" : "projector";
      updateDraft();
      message("Default selected for screen " + id + ". Publish to apply it.");
    };
  }
  for (const button of document.querySelectorAll("[data-preview]")) {
    button.onclick = () => {
      const id = Number(button.dataset.preview);
      const mode = el("mode" + id).value;
      const value = mode === "website" ? el("url" + id).value.trim() :
        location.origin + "/" + (mode === "robot" ? "robot" : "projector") + "?display=1";
      try {
        const url = new URL(value);
        if (!["http:", "https:"].includes(url.protocol) || url.username || url.password) throw new Error();
        window.open(url.href, "_blank", "noopener,noreferrer");
      } catch (_) { message("Enter a valid http:// or https:// website link before previewing.", true); }
    };
  }
  for (const button of document.querySelectorAll("[data-refresh]")) {
    button.onclick = async () => {
      if (busy || !saved) return;
      const id = Number(button.dataset.refresh);
      setBusy(true);
      try {
        const data = await api("/api/content/refresh", {revision: saved.revision, screen: id});
        showSettings(data, false);
        message("Reload requested for screen " + id + ". Unpublished edits have not been sent.");
      } catch (error) { message(error.message, true); await pollStatus(true); }
      finally { setBusy(false); }
    };
  }
  async function pollStatus(force = false) {
    if (!saved || statusBusy || (busy && !force)) return;
    statusBusy = true;
    const revisionAtStart = saved.revision;
    try {
      const data = await api("/api/content/status");
      if (saved.revision === revisionAtStart && (!busy || force)) showStatus(data);
    } catch (_) {
      el("launcherStatus").textContent = "Cannot reach CAT server";
      el("launcherStatus").className = "badge badge-yellow";
      for (const id of [1, 2]) {
        el("state" + id).textContent = "Display status unavailable";
        el("state" + id).className = "screen-state badge badge-yellow";
      }
    } finally { statusBusy = false; }
  }
  window.addEventListener("beforeunload", event => {
    if (dirty()) { event.preventDefault(); event.returnValue = ""; }
  });
  loadSettings();
  setInterval(pollStatus, 3000);
})();

