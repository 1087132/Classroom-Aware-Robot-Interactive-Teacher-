#!/usr/bin/env python3
"""Add only CAT window rules/autostart; preserve timestamped desktop backups."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--screen1", default="HDMI-A-1")
    parser.add_argument("--screen2", default="HDMI-A-2")
    args = parser.parse_args()
    if os.geteuid() == 0:
        raise SystemExit("Run from the Pi desktop terminal WITHOUT sudo.")
    if not os.environ.get("WAYLAND_DISPLAY") or subprocess.run(
            ["pgrep", "-x", "labwc"], stdout=subprocess.DEVNULL).returncode:
        raise SystemExit("This display setup targets Raspberry Pi OS with labwc/Wayland. "
                         "Run it inside that desktop. The CMS itself can still run on other desktops.")
    if args.screen1 == args.screen2:
        raise SystemExit("Choose two different HDMI outputs.")
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("cat_launcher", here / "launch-displays.py")
    launcher = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(launcher)
    try:
        names = [args.screen1, args.screen2]
        detected = [item["name"] for item in launcher.outputs()]
        if not all(name in detected for name in names):
            raise SystemExit("Detected outputs: " + ", ".join(detected) +
                             ". Connect both screens or specify --screen1 NAME --screen2 NAME.")
    except (subprocess.CalledProcessError, json.JSONDecodeError) as error:
        raise SystemExit("This launcher needs wlr-randr with --json support. "
                         "Send the output of: cat /etc/os-release ; wlr-randr --help") from error
    config = Path.home() / ".config/labwc"
    config.mkdir(parents=True, exist_ok=True)
    rc = config / "rc.xml"
    system_rc = Path("/etc/xdg/labwc/rc.xml")
    source = rc if rc.exists() else system_rc
    if not source.exists():
        raise SystemExit("No existing labwc rc.xml found; no desktop settings were changed.")
    parser_xml = ET.XMLParser(target=ET.TreeBuilder(insert_comments=True))
    tree = ET.parse(source, parser=parser_xml)
    root = tree.getroot()
    namespace = root.tag.partition("}")[0] + "}" if root.tag.startswith("{") else ""
    if namespace:
        ET.register_namespace("", namespace[1:-1])
    rules = root.find(namespace + "windowRules")
    if rules is None:
        rules = ET.SubElement(root, namespace + "windowRules")
    for child in list(rules):
        if child.get("identifier") in ("cat-teacher-screen-1", "cat-teacher-screen-2", "cat-screen-1", "cat-screen-2"):
            rules.remove(child)
    for number, output in enumerate(names, 1):
        rule = ET.SubElement(rules, namespace + "windowRule", {"identifier": f"cat-teacher-screen-{number}"})
        ET.SubElement(rule, namespace + "action", {"name": "MoveToOutput", "output": output})
        ET.SubElement(rule, namespace + "action", {"name": "ToggleFullscreen"})
    autostart = config / "autostart"
    system_autostart = Path("/etc/xdg/labwc/autostart")
    if autostart.exists():
        startup = autostart.read_text()
    elif system_autostart.exists():
        startup = system_autostart.read_text()
    else:
        raise SystemExit("No labwc autostart file found; no desktop settings were changed.")
    startup = "\n".join(line for line in startup.splitlines() if "/opt/cat-display-starter/launch-displays.py" not in line and line.strip() != "# CAT display starter") + "\n"
    marker = "# CAT teacher displays"
    line = 'python3 /opt/cat-teacher/pi/launch-displays.py >> "$HOME/.local/share/cat-teacher-displays/launcher.log" 2>&1 &'
    if marker not in startup:
        # Avoid appending after an explicit exit/exec, which would prevent launch.
        for existing in startup.splitlines():
            if existing.lstrip().startswith(("exit", "exec ")):
                raise SystemExit("Your autostart has an exit/exec line. Manual integration is needed; no files changed.")
        startup = startup.rstrip() + "\n\n" + marker + "\n" + line + "\n"
    stamp = time.strftime("%Y%m%d-%H%M%S")
    backups = config / f"cat-backup-{stamp}"
    backups.mkdir()
    manifest = {"rc_existed": rc.exists(), "autostart_existed": autostart.exists()}
    shutil.copy2(source, backups / "rc.xml")
    (backups / "autostart").write_text(autostart.read_text() if autostart.exists() else system_autostart.read_text())
    (backups / "manifest.json").write_text(json.dumps(manifest, indent=2))
    base = Path.home() / ".local/share/cat-teacher-displays"
    base.mkdir(parents=True, exist_ok=True, mode=0o700)
    (base / "outputs.json").write_text(json.dumps(names))
    tree.write(rc, encoding="utf-8", xml_declaration=True)
    autostart.write_text(startup)
    subprocess.run(["labwc", "--reconfigure"], check=True)
    launcher.arrange(names)
    print(f"Saved desktop backups: {backups}")
    print("Configured separate display windows. Start them now with:")
    print("python3 /opt/cat-teacher/pi/launch-displays.py")
    print("They will also start at the next desktop login. Desktop shortcuts are unchanged.")


if __name__ == "__main__":
    main()
