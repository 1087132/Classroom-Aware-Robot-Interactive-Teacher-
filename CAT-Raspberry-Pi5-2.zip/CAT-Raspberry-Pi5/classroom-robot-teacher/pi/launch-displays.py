#!/usr/bin/env python3
"""Poll the local Content Manager and run one browser per physical display."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import urllib.request
from urllib.parse import urlsplit

BASE_URL = "http://127.0.0.1:8000"


def outputs():
    result = subprocess.run(["wlr-randr", "--json"], check=True, text=True, capture_output=True)
    value = json.loads(result.stdout)
    if not isinstance(value, list):
        raise RuntimeError("Unexpected wlr-randr JSON format.")
    return value


def arrange(names):
    available = {output["name"]: output for output in outputs()}
    if any(name not in available for name in names):
        raise RuntimeError("Both configured HDMI screens must be connected and switched on.")
    first = available[names[0]]
    modes = first.get("modes", [])
    mode = next((m for m in modes if m.get("current")), None)
    if mode is None:
        mode = next((m for m in modes if m.get("preferred")), None)
    if not mode:
        raise RuntimeError("No usable mode was found for the first HDMI screen.")
    width = round(mode["width"] / first.get("scale", 1))
    transform = str(first.get("transform", "normal"))
    if transform in ("90", "270", "flipped-90", "flipped-270"):
        width = round(mode["height"] / first.get("scale", 1))
    subprocess.run(["wlr-randr", "--output", names[0], "--on", "--pos", "0,0",
                    "--output", names[1], "--on", "--pos", f"{width},0"], check=True)


def request_json(path, body=None):
    data = None if body is None else json.dumps(body).encode("utf-8")
    request = urllib.request.Request(BASE_URL + path, data=data,
        headers={"Content-Type": "application/json", "X-CAT-Request": "1"})
    with urllib.request.urlopen(request, timeout=2) as response:
        return json.load(response)


def display_target(screen):
    mode = screen.get("mode")
    if mode in ("robot", "projector"):
        return BASE_URL + "/" + mode + "?display=1"
    url = screen.get("url", "")
    parsed = urlsplit(url)
    if mode != "website" or parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("The saved screen URL is invalid.")
    return url


def stop_browser(process):
    """Stop only the process group this launcher created."""
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    try:
        process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        process.wait(timeout=3)


class Display:
    def __init__(self, number, output, chromium, base):
        self.number, self.output, self.chromium, self.base = number, output, chromium, base
        self.process = None
        self.version = 0
        self.target = ""
        self.message = ""
        self.retry_at = 0
        self.started_at = 0

    def apply(self, screen):
        target = display_target(screen)
        changed = screen["version"] != self.version or target != self.target
        running = self.process is not None and self.process.poll() is None
        if not changed and (running or time.monotonic() < self.retry_at):
            return
        if self.process is not None:
            stop_browser(self.process)
            self.process = None
        args = [self.chromium, "--ozone-platform=x11", f"--class=cat-teacher-screen-{self.number}",
                f"--user-data-dir={self.base / ('screen-' + str(self.number))}",
                "--no-first-run", "--no-default-browser-check", "--app=" + target]
        self.version, self.target = screen["version"], target
        self.retry_at = time.monotonic() + 10
        self.started_at = time.monotonic()
        try:
            self.process = subprocess.Popen(args, stdout=subprocess.DEVNULL, start_new_session=True)
            self.message = ""
        except OSError as error:
            self.message = "Chromium could not start: " + str(error)

    def report(self, stopped=False):
        if stopped:
            state = "stopped"
        elif self.process is None or self.process.poll() is not None:
            state = "error"
        elif time.monotonic() - self.started_at < 1:
            state = "starting"
        else:
            state = "running"
        return {"id": self.number, "output": self.output, "version": self.version,
                "status": state, "message": self.message or
                ("Browser exited; retrying shortly." if state == "error" else "")}


def launcher_pids():
    """Find this user's existing copy, including the previous empty-lock version."""
    script = Path(__file__).resolve()
    for entry in Path("/proc").iterdir():
        if not entry.name.isdigit() or int(entry.name) == os.getpid():
            continue
        try:
            if entry.stat().st_uid != os.getuid():
                continue
            args = (entry / "cmdline").read_bytes().split(b"\0")
            if (len(args) > 1 and Path(os.fsdecode(args[0])).name.startswith("python")
                    and Path(os.fsdecode(args[1])).is_absolute()
                    and Path(os.fsdecode(args[1])).resolve() == script):
                yield int(entry.name)
        except (OSError, ValueError):
            continue


def acquire_lock(path, restart=False):
    lock = path.open("a+")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        if not restart:
            lock.close()
            raise SystemExit("CAT displays are already running. Use --restart to load an updated launcher.") from None
        for pid in launcher_pids():
            try:
                os.kill(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        for _ in range(100):
            time.sleep(0.2)
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                continue
        else:
            lock.close()
            raise SystemExit("Stop the existing CAT launcher with Ctrl+C in its terminal, then retry.") from None
    lock.seek(0)
    lock.truncate()
    lock.write(str(os.getpid()))
    lock.flush()
    return lock


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--restart", action="store_true", help="Replace this user's running CAT display launcher.")
    args = parser.parse_args()
    if os.geteuid() == 0:
        raise SystemExit("Run this as the desktop user, without sudo.")
    base = Path.home() / ".local/share/cat-teacher-displays"
    base.mkdir(parents=True, exist_ok=True, mode=0o700)
    if not (base / "outputs.json").exists():
        raise SystemExit("First run: python3 /opt/cat-teacher/pi/setup-displays.py")
    names = json.loads((base / "outputs.json").read_text())
    if not isinstance(names, list) or len(names) != 2 or len(set(names)) != 2:
        raise SystemExit("Invalid HDMI settings. Run setup-displays.py again.")
    chromium = shutil.which("chromium") or shutil.which("chromium-browser")
    if not chromium:
        raise SystemExit("Chromium is missing. Run install-pi.sh first.")
    lock = acquire_lock(base / "launcher.lock", args.restart)
    stop = False

    def stopping(signum, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    for _ in range(30):
        if stop:
            lock.close()
            return
        try:
            health = request_json("/health")
            if health.get("ready") and health.get("application") == "cat-teacher":
                arrange(names)
                config = request_json("/api/display-config")
                break
        except Exception as error:
            print(f"Waiting for displays/server: {error}", flush=True)
        time.sleep(2)
    else:
        lock.close()
        raise SystemExit("Display startup failed. Check both HDMI cables and the cat-teacher service.")
    displays = [Display(number, names[number - 1], chromium, base) for number in (1, 2)]
    last_error = None
    try:
        while not stop:
            try:
                config = request_json("/api/display-config")
                if last_error:
                    print("Content Manager reconnected.", flush=True)
                last_error = None
            except Exception as error:
                if str(error) != last_error:
                    print(f"Keeping current displays while CAT reconnects: {error}", flush=True)
                    last_error = str(error)
            for display, screen in zip(displays, config["screens"]):
                display.apply(screen)
            try:
                request_json("/api/display-status", {"screens": [display.report() for display in displays]})
            except Exception:
                pass
            time.sleep(2)
    finally:
        for display in displays:
            stop_browser(display.process)
        try:
            request_json("/api/display-status", {"screens": [display.report(stopped=True) for display in displays]})
        except Exception:
            pass
        lock.close()


if __name__ == "__main__":
    main()
