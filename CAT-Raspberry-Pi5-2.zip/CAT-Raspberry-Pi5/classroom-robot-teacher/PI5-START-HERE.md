# Run your CAT website on Raspberry Pi 5

This package adapts your existing FastAPI application. The same backend serves
the frontend pages, student app, and live WebSockets; there is no separate Node
frontend server to start.

| Use | Address on the Pi |
| --- | --- |
| Teacher login and controls | http://127.0.0.1:8000/teacher |
| Teacher Content Manager | http://127.0.0.1:8000/content |
| HDMI screen 1: robot face | http://127.0.0.1:8000/robot?display=1 |
| HDMI screen 2: lesson/projector | http://127.0.0.1:8000/projector?display=1 |
| Student interface | http://PI-LAN-IP:8000/student |

The service for this project is **cat-teacher**, on **port 8000**. The earlier
generic starter used a different service and port. It is not needed for this
project. The new display setup removes only the old starter's known autostart
line and window rules, after taking a backup.

## Updating a working CAT installation

Extract this new ZIP into a new folder. Open a terminal inside its
`classroom-robot-teacher` folder and run:

```bash
sudo bash install-pi.sh
```

Wait for **CAT READY**. The installer retains your existing teacher account and
service data, including published screen links. It backs up the database and
installed application files before replacing the code.

Then run this in the Pi desktop terminal, **without sudo**:

```bash
python3 /opt/cat-teacher/pi/launch-displays.py --restart
```

This replaces your existing CAT display launcher and reloads both display
windows once. After that, publishing changes reloads only the affected screen.
Your existing HDMI setup is reused. If the launcher says settings are missing,
follow section 2 below. Leave the launcher terminal running, or log out and back
in to use the existing desktop autostart.

Open **http://127.0.0.1:8000/content** in your normal browser on the Pi and sign
in with your existing teacher account. Press **Alt+Tab** if you need to switch
away from a display window. Use **Ctrl+Shift+R** once if an existing page still
shows the old navigation.

## Manage website links

1. Open **Content Manager** in the teacher navigation.
2. For Screen 1, choose **Website link** and paste the complete web address.
3. Do the same for Screen 2. The two addresses can be different.
4. Click **Publish to screens**. When the launcher is connected, changed screens
   briefly close and reopen with the new content, usually within a few seconds.
5. Use **CAT robot face** or **CAT lesson / projector** to return to a built-in
   CAT view. **Use default** selects robot for Screen 1 or lesson for Screen 2;
   click Publish to apply it.

**Open preview** opens the draft link in your current browser. It does not
change an HDMI screen. **Reload screen 1/2** reloads that screen's saved content
and leaves unpublished edits in the form. **Discard edits** restores the form
to the last settings you loaded; it does not change the running displays.

Friendly screen names are optional to change. Renaming a screen does not
restart its browser. Settings are saved in SQLite and survive reboot. If
another teacher window publishes first, the page asks you to load the latest
settings before overwriting them.

Each website opens directly in its own Chromium window, without embedding it
inside CAT. Internet sites need internet access. Sites requiring login must be
signed in separately on the appropriate display; browser profiles are separate.
Video autoplay and website access remain subject to the site's/browser's rules.
Do not put passwords in the website URL.

The dashboard reports whether the launcher is connected and its browser
processes are running. This does **not** verify that an external website loaded
successfully; check the physical screens. If the CAT server is temporarily
unavailable, the launcher keeps the current windows and retries. Reopening the
launcher later uses the latest published choices.

Teacher login protects publishing and reloading controls. The two display
profiles do not need a teacher login. The existing desktop access limitations
described in section 2 still apply. Website mode replaces the built-in CAT view
on that screen; CAT lesson/robot events are shown again when you switch back.

## 1. Install the actual project

Extract the ZIP on the Pi. Inside it, open the `classroom-robot-teacher` folder
(the folder containing `install-pi.sh`). Open a Terminal in that folder and run:

```bash
sudo bash install-pi.sh
```

Use Raspberry Pi OS with the desktop and an internet connection for package
installation. This does not reflash the SD card. The installer uses Raspberry Pi
OS packages in a Python virtual environment; it avoids installing large AI
models just to get the dashboard working.

When asked, create a private teacher passphrase of **14-256 characters**. Nothing
appears while typing. Enter it twice. An invalid length or mismatch prompts
another attempt. The username for a new installation is **teacher**.

Existing teacher accounts with private passwords are retained. The previous
shared default password is rejected and must be replaced. Existing service data
is backed up before an update. If the extracted project has `data/cat.db`, the
installer copies it into the service data directory using SQLite's backup API.

Wait for **CAT READY: http://127.0.0.1:8000/teacher**. This message appears only
after the service responds successfully. If startup fails, the installer prints
the relevant service logs. Send that error instead of repeatedly starting the
display launcher.

Open the teacher address on the Pi and sign in. You can change your password
later using the **Password** link in the top navigation.

## 2. Start the two displays

Connect both screens and switch them on. Open a Terminal **on the Pi desktop**
and run these commands without sudo:

```bash
python3 /opt/cat-teacher/pi/setup-displays.py
python3 /opt/cat-teacher/pi/launch-displays.py
```

The setup targets Raspberry Pi OS's **labwc/Wayland** desktop. It checks the
desktop and connector names, saves timestamped backups, arranges the screens
side by side, adds app-specific window rules, and adds the launcher to desktop
autostart. It does not change the rest of the desktop to X11; only the two
Chromium windows use XWayland so their classes can be matched reliably.

Default mapping: **HDMI-A-1 = robot face**, **HDMI-A-2 = projector**. Physical
port labels may be HDMI0 and HDMI1. To swap them, run:

```bash
python3 /opt/cat-teacher/pi/setup-displays.py --screen1 HDMI-A-2 --screen2 HDMI-A-1
```

Then log out and back in, or stop the launcher with Ctrl+C in its original
Terminal and launch it again (or use `launch-displays.py --restart` as above).
No window dragging is necessary. Two separate
Chromium profiles are used; neither needs a teacher login.

The backend starts at boot. The two display windows start **when the desktop
user logs in**. If your Pi already uses desktop autologin, they will appear
after boot. This package does not enable autologin to your privileged account.

If an old starter launcher is still running in a Terminal, stop it with Ctrl+C
before starting the new launcher. For a background launcher, identify its PID
with `pgrep -af launch-displays.py`, then stop only that identified process.

Display mode hides the home/theme navigation on the two HDMI views. It does
**not** password-lock the operating system. If students can use a privileged
desktop, attach a keyboard, or remove the SD card, web login cannot protect the
whole device. For display-only use, keep the Pi and its ports out of reach and
remove the keyboard/mouse. Interactive classroom use needs a separately tested
restricted desktop account; this installer does not lock you out of your Pi.

## 3. Manage lessons from your laptop

Teacher pages and teacher APIs are intentionally limited to connections from
the Pi itself. Student devices on the LAN can access the student and display
pages. For teacher access from a laptop, use an SSH tunnel so the password and
teacher data do not travel over plain classroom HTTP.

On the Pi, find the username and LAN address:

```bash
whoami
hostname -I
```

If SSH is not enabled, enable it through Raspberry Pi OS settings or:

```bash
sudo systemctl enable --now ssh
```

On the laptop, replace the placeholders with the Pi username and LAN address:

```bash
ssh -N -L 8000:127.0.0.1:8000 PI_USER@PI_ADDRESS
```

Check the SSH host fingerprint on first connection against the trusted Pi
console (`ssh-keygen -lf /etc/ssh/ssh_host_ed25519_key.pub`). Leave the SSH
Terminal open and browse to **http://127.0.0.1:8000/teacher on the laptop**.
Sign in using the teacher passphrase. The SSH account password is separate.
If laptop port 8000 is already in use, use
`ssh -N -L 8081:127.0.0.1:8000 PI_USER@PI_ADDRESS` and browse to
`http://127.0.0.1:8081/teacher` instead.

Students use the Pi's actual LAN address and port 8000, not 127.0.0.1. The
projector QR code provides the join link. Use a trusted classroom network; do
not expose this prototype to the internet with router port forwarding.

## What changed in your project

- Private teacher setup replaces automatic creation of a shared default account.
- The teacher-only Content Manager assigns a website or a built-in CAT view
  to each screen. The local desktop launcher polls saved settings, restarts
  only changed screens, and reports browser process status.
- Teacher controls, camera/analytics/history APIs, and teacher WebSocket roles
  require authentication. Teacher management is restricted to local/tunneled
  access by default. New non-public APIs default to requiring teacher login.
- Browser write requests need a same-origin request and the app's request header.
- Sessions expire after two hours. Logout and password changes revoke sessions;
  revoked teacher WebSockets are closed when sending or checking the connection.
- Public viewers do not receive teacher schedules, transcripts, tracking alerts,
  or per-student engagement history. The projector retains its intended class
  totals and pseudonymous points leaderboard. Personal answer feedback is sent
  only to the joined student's browser session and the authenticated teacher.
- Student answer submissions are tied to the current browser's join session.
  Existing student codes remain join identifiers, not strong identity passwords.
- Teacher/API responses are not cached. The updated service worker deletes the
  old CAT cache and caches only static assets. After upgrading an existing
  browser session, reload once with Ctrl+Shift+R to load the current scripts.
- Runtime database, uploaded lessons, PDFs, and optional voice files live under
  `/var/lib/cat-teacher`, separate from root-owned installed code.

The existing lesson engine, classroom UI, robot animation, and optional AI
modules remain the basis of the app. This is not a full security audit or a
claim of validated classroom perception/AI performance.

## Optional camera and AI features

The initial Pi installation runs the web app and existing simulation/retrieval
fallbacks. It does not download Ollama models or the Kokoro voice model.
Hardware/model features need separate Pi testing and resources.

For a USB camera, the existing OpenCV module can be enabled after installing
the distro package and granting the service access to video devices:

```bash
sudo apt install python3-opencv
sudo usermod -aG video cat-teacher
sudo systemctl restart cat-teacher
```

If your distro OpenCV package lacks bundled Haar cascade files, configure that
module's cascade path before using camera mode. The normal display/lesson mode
works without OpenCV. Browser speech synthesis and microphone capabilities vary
by browser and device. Camera accuracy, speech, Ollama, and Kokoro performance
have not been validated on your Pi by this update.

## Troubleshooting and maintenance

The current service name is **cat-teacher**:

```bash
sudo systemctl status cat-teacher --no-pager -l
sudo journalctl -u cat-teacher -b -n 40 --no-pager
```

Display launcher logs:

```bash
cat ~/.local/share/cat-teacher-displays/launcher.log
```

Reset a forgotten teacher password from an admin terminal on the Pi:

```bash
cd /opt/cat-teacher
sudo -u cat-teacher env CAT_DATA_DIR=/var/lib/cat-teacher .venv/bin/python -m backend.manage_teacher --username teacher
sudo systemctl restart cat-teacher
```

Restarting revokes any existing in-memory login sessions. Runtime configuration
is in `/etc/cat-teacher.env`; set `CAT_PUBLIC_HOST` there if automatic LAN address
detection gives the wrong student QR link, then restart the service.

Stop the backend with `sudo systemctl disable --now cat-teacher`. Desktop backups
are in `~/.config/labwc/cat-backup-TIMESTAMP/`, with a manifest recording whether
the user config files originally existed. Restore/merge those files to undo the
display integration, preserving any later desktop edits. Data is not deleted.

## Checks and limitations

See `tests/test_pi_access.py` for application tests covering teacher permissions,
CSRF/origin checks, password/session behavior, WebSocket separation, student
joining/answering, and writable uploaded lessons. The actual Pi's HDMI output,
service manager, ARM packages, browser rendering, camera, and model runtimes
cannot be exercised in this workspace. Those require checking on the Pi.
The additional `tests/test_content.py` and `tests/test_display_launcher.py`
cover link validation, persistence, publish conflicts, local launcher access,
status expiry, and browser restart selection with mocked processes.

References: [Raspberry Pi Python environments](https://www.raspberrypi.com/documentation/computers/os.html),
[labwc window rules](https://labwc.github.io/labwc-config.5),
[OWASP WebSocket security](https://cheatsheetseries.owasp.org/cheatsheets/WebSocket_Security_Cheat_Sheet.html).
