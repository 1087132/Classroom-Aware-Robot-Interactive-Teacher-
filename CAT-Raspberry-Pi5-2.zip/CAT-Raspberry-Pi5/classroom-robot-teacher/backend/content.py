"""Teacher-published website assignments for the two physical displays."""
import ipaddress
import json
import re
import time
from urllib.parse import urlsplit

from . import database as db

DEFAULTS = [
    {"id": 1, "label": "Screen 1", "mode": "robot", "url": "", "version": 1},
    {"id": 2, "label": "Screen 2", "mode": "projector", "url": "", "version": 1},
]
_heartbeat = {"received_at": 0, "screens": []}


class Conflict(ValueError):
    pass


def validate_url(value):
    if not isinstance(value, str):
        raise ValueError("Enter a website URL.")
    value = value.strip()
    if len(value) > 2048 or any(ord(c) < 33 or ord(c) == 127 for c in value) or "\\" in value:
        raise ValueError("Use a website URL without spaces, control characters or backslashes.")
    try:
        parsed = urlsplit(value)
        host = (parsed.hostname or "").lower().rstrip(".")
        port = parsed.port
    except ValueError:
        raise ValueError("Enter a valid website URL, including https:// or http://.") from None
    if parsed.scheme not in ("http", "https") or not host:
        raise ValueError("Website links must start with https:// or http://.")
    if parsed.username is not None or parsed.password is not None:
        raise ValueError("Do not include a username or password inside the website URL.")
    if host == "localhost" or host.endswith(".localhost"):
        raise ValueError("Use the CAT robot/lesson option for built-in views, not a localhost link.")
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        address = None
        if re.fullmatch(r"(?:0x[0-9a-f]+|[0-9]+)(?:\.(?:0x[0-9a-f]+|[0-9]+))*", host):
            raise ValueError("Use a normal website hostname or a complete IP address.")
    if address:
        mapped = getattr(address, "ipv4_mapped", None)
        if address.is_loopback or address.is_unspecified or (mapped and (mapped.is_loopback or mapped.is_unspecified)):
            raise ValueError("Use the built-in CAT options instead of a loopback address.")
    if port == 0:
        raise ValueError("The website port must be between 1 and 65535.")
    return value


def validate_screens(value):
    if not isinstance(value, list) or len(value) != 2:
        raise ValueError("Provide settings for both screens.")
    result = []
    for number, item in enumerate(value, 1):
        if not isinstance(item, dict) or type(item.get("id")) is not int or item["id"] != number:
            raise ValueError("The screens must be Screen 1 and Screen 2, in that order.")
        label = item.get("label", f"Screen {number}")
        mode = item.get("mode")
        if not isinstance(label, str) or not 1 <= len(label.strip()) <= 80:
            raise ValueError("Give each screen a label of 1-80 characters.")
        if mode not in ("robot", "projector", "website"):
            raise ValueError("Choose Robot face, Lesson/projector, or Website link.")
        url = validate_url(item.get("url")) if mode == "website" else ""
        result.append({"id": number, "label": label.strip(), "mode": mode, "url": url})
    return result


def _ensure(connection):
    connection.execute("""CREATE TABLE IF NOT EXISTS display_content (
        id INTEGER PRIMARY KEY CHECK(id=1), revision INTEGER NOT NULL,
        content_json TEXT NOT NULL, updated_at REAL NOT NULL, updated_by TEXT NOT NULL)""")
    connection.execute("INSERT OR IGNORE INTO display_content VALUES (1, 1, ?, 0, '')", (json.dumps(DEFAULTS),))


def _read(connection):
    row = connection.execute("SELECT * FROM display_content WHERE id=1").fetchone()
    return {"revision": row["revision"], "screens": json.loads(row["content_json"]),
            "updated_at": row["updated_at"], "updated_by": row["updated_by"]}


def get_settings():
    connection = db.get_conn()
    try:
        with connection:
            _ensure(connection)
            return _read(connection)
    finally:
        connection.close()


def publish(screens, expected_revision, username, refresh_id=None):
    if type(expected_revision) is not int:
        raise ValueError("Reload the saved settings before publishing.")
    clean = validate_screens(screens) if refresh_id is None else None
    if refresh_id is not None and (type(refresh_id) is not int or refresh_id not in (1, 2)):
        raise ValueError("Choose Screen 1 or Screen 2 to reload.")
    connection = db.get_conn()
    try:
        with connection:
            connection.execute("BEGIN IMMEDIATE")
            _ensure(connection)
            current = _read(connection)
            if current["revision"] != expected_revision:
                raise Conflict("Another teacher window changed these settings. Reload saved settings before publishing.")
            next_screens = []
            for index, old in enumerate(current["screens"]):
                new = dict(clean[index]) if clean is not None else {k: old[k] for k in ("id", "label", "mode", "url")}
                changed_target = any(new[key] != old[key] for key in ("mode", "url"))
                new["version"] = old["version"] + int(changed_target or refresh_id == old["id"])
                next_screens.append(new)
            if next_screens == current["screens"]:
                return current
            connection.execute("UPDATE display_content SET revision=revision+1, content_json=?, updated_at=?, updated_by=? WHERE id=1",
                               (json.dumps(next_screens), time.time(), username))
            return _read(connection)
    finally:
        connection.close()


def record_heartbeat(screens):
    if not isinstance(screens, list) or len(screens) != 2:
        raise ValueError("Expected status for two screens.")
    clean = []
    for number, screen in enumerate(screens, 1):
        if not isinstance(screen, dict) or type(screen.get("id")) is not int or screen.get("id") != number:
            raise ValueError("Invalid screen status.")
        version = screen.get("version")
        if type(version) is not int or version < 0 or screen.get("status") not in ("running", "starting", "error", "stopped"):
            raise ValueError("Invalid browser state.")
        clean.append({"id": number, "version": version, "status": screen["status"],
                      "output": str(screen.get("output", ""))[:80],
                      "message": str(screen.get("message", ""))[:200]})
    _heartbeat.update(received_at=time.time(), screens=clean)


def status():
    return {**_heartbeat, "online": bool(_heartbeat["received_at"] and time.time() - _heartbeat["received_at"] < 15)}
