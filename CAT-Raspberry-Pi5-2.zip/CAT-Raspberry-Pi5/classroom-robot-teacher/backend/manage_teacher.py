"""Create/reset a teacher account from a trusted terminal."""
import argparse
import getpass
from . import auth
from . import database as db


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ensure", action="store_true")
    parser.add_argument("--username", default="teacher")
    args = parser.parse_args()
    db.init_db()
    if args.ensure:
        accounts = db.list_teachers()
        targets = [t["username"] for t in accounts if auth.is_legacy_default(db.get_teacher(t["username"]))]
        if accounts and not targets:
            print("Existing teacher account retained.")
            return
        if not accounts:
            targets = [args.username]
    else:
        targets = [args.username]
    for username in targets:
        print(f"Set a private passphrase for teacher account: {username}")
        for _ in range(3):
            password = getpass.getpass("New passphrase (14-256 characters; typing is hidden): ")
            if not 14 <= len(password) <= 256:
                print("The passphrase must contain 14-256 characters. Try again.")
                continue
            if password != getpass.getpass("Repeat passphrase: "):
                print("The entries did not match. Try again.")
                continue
            auth.set_password(username, password)
            print("Teacher passphrase saved.")
            break
        else:
            raise SystemExit("Setup is incomplete. Run the command again.")


if __name__ == "__main__":
    try:
        main()
    except (KeyboardInterrupt, EOFError):
        raise SystemExit("\nPassword setup cancelled; no default password will be used.") from None
