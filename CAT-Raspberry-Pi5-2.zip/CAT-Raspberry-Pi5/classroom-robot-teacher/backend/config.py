"""Runtime files live outside the installed, read-only application."""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("CAT_DATA_DIR", str(ROOT / "data"))).expanduser().resolve()
LESSONS_DIR = DATA_DIR / "lessons"
ADMIN_LOOPBACK_ONLY = os.environ.get("CAT_ADMIN_LOOPBACK_ONLY", "1") != "0"
