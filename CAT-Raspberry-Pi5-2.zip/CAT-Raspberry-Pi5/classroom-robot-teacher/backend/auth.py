"""Teacher authentication with private setup and expiring server-side sessions."""
import hashlib
import secrets
import time
from . import database as db

COOKIE_NAME = "cat_auth"
SESSION_TTL = 2 * 3600
ITERATIONS = 600_000
_sessions = {}
_attempts = []
STUDENT_COOKIE = "cat_student_session"
_students = {}


def bind_student(token, student_id, session_id):
    now = time.time()
    for key, value in list(_students.items()):
        if value["expires"] <= now:
            _students.pop(key, None)
    if token not in _students:
        token = secrets.token_hex(32)
    _students[token] = {"id": student_id, "session": session_id, "expires": now + 12 * 3600}
    return token


def student_id(token, session_id):
    student = _students.get(token or "")
    if student and student["expires"] > time.time() and student["session"] == session_id:
        return student["id"]
    return None


def _hash_pw(password, salt_hex, iterations=ITERATIONS):
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt_hex), iterations).hex()
    return f"pbkdf2_sha256${iterations}${digest}"


def _verify(password, teacher):
    stored = teacher["pw_hash"]
    if stored.startswith("pbkdf2_sha256$"):
        try:
            _, iterations, _ = stored.split("$")
            return secrets.compare_digest(_hash_pw(password, teacher["pw_salt"], int(iterations)), stored)
        except (ValueError, TypeError):
            return False
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(teacher["pw_salt"]), 100_000).hex()
    return secrets.compare_digest(digest, stored)


def is_legacy_default(teacher):
    return bool(teacher and _verify("teach123", teacher))


def ensure_default_teacher():
    """Compatibility name: require private setup instead of seeding a shared password."""
    teachers = db.list_teachers()
    if not teachers or any(is_legacy_default(db.get_teacher(t["username"])) for t in teachers):
        raise RuntimeError("Teacher setup required. Run: python -m backend.manage_teacher --ensure")


def set_password(username, password):
    import re
    username = username.strip().lower()
    if not re.fullmatch(r"[a-z0-9_-]{1,40}", username):
        raise ValueError("Username: use 1-40 letters, numbers, underscores or hyphens.")
    if not 14 <= len(password) <= 256:
        raise ValueError("Use a passphrase between 14 and 256 characters.")
    salt = secrets.token_hex(16)
    if db.get_teacher(username):
        db.update_teacher_password(username, salt, _hash_pw(password, salt))
    else:
        db.create_teacher(username, salt, _hash_pw(password, salt))
    for token, session in list(_sessions.items()):
        if session["username"] == username:
            _sessions.pop(token, None)


def login(username, password):
    if not isinstance(username, str) or not isinstance(password, str) or len(username) > 40 or len(password) > 256:
        return None
    username = username.strip().lower()
    now = time.time()
    _attempts[:] = [t for t in _attempts if now - t < 300]
    if len(_attempts) >= 10:
        return None
    teacher = db.get_teacher(username)
    valid = bool(teacher and not is_legacy_default(teacher) and _verify(password, teacher))
    if not valid:
        _attempts.append(now)
        return None
    _attempts.clear()
    if not teacher["pw_hash"].startswith("pbkdf2_sha256$"):
        salt = secrets.token_hex(16)
        db.update_teacher_password(username, salt, _hash_pw(password, salt))
    for token, session in list(_sessions.items()):
        if session["expires"] <= now:
            _sessions.pop(token, None)
    token = secrets.token_hex(32)
    _sessions[token] = {"username": username, "expires": now + SESSION_TTL}
    return token


def check(token):
    session = _sessions.get(token or "")
    if not session:
        return None
    if session["expires"] <= time.time():
        _sessions.pop(token, None)
        return None
    return session["username"]


def logout(token):
    _sessions.pop(token or "", None)


def change_password(username, old_password, new_password):
    teacher = db.get_teacher(username)
    if (not teacher or not isinstance(old_password, str) or not isinstance(new_password, str)
            or len(old_password) > 256 or not 14 <= len(new_password) <= 256
            or not _verify(old_password, teacher)):
        return False
    set_password(username, new_password)
    return True
