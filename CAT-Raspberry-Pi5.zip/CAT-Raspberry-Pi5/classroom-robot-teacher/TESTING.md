# Verification of the Raspberry Pi adaptation

Automated run: **19 passed, 1 skipped**, using Python 3.12 with FastAPI and
Starlette's in-process HTTP/WebSocket test client.

Covered: all teacher API permissions; protected pages; private account login;
cross-origin/write-request rejection; teacher access over local/tunneled versus
direct LAN connections; session expiry and password-change revocation; response
cache headers; authenticated teacher WebSockets; rejection of foreign origins;
teacher/public event separation; WebSocket closure after logout; existing lesson
startup; student join/answer flow with browser binding; writable lesson uploads;
public engagement summaries and individual feedback filtering.

The QR SVG test is skipped when `qrcode` is absent. That package was unavailable
in the build runtime and could not be downloaded there; `install-pi.sh` installs
and checks the Raspberry Pi OS `python3-qrcode` package before starting the app.

Python compilation, shell syntax, shared JavaScript syntax, and inline JavaScript
syntax in all eight frontend pages passed.

Not tested here: a real Pi 5, systemd execution, ARM package installation,
physical HDMI placement, boot/login autostart, browser rendering, QR generation,
camera access, speech/audio, neural models, or sustained classroom operation.
The build environment cannot start Chromium, so no visual or browser end-to-end
verification is claimed. These checks are application tests, not a full audit.

Run the tests from the project directory in an environment with the core
requirements plus `httpx`:

```bash
python -m unittest discover -s tests -v
```
