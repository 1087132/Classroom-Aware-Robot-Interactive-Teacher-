"""Permissions for teacher controls and data sent to public displays."""
import ipaddress
from . import auth
from .config import ADMIN_LOOPBACK_ONLY

TEACHER_ROLES = {"teacher", "tracking"}
PUBLIC_ROLES = {"student", "robot", "projector", "viewer"}
PUBLIC_EVENTS = {"state", "expression", "speak", "speaker_state", "stage", "question_open",
                 "question_closed", "question_tick", "minigame_start"}


def admin_transport(connection):
    if not ADMIN_LOOPBACK_ONLY:
        return True
    try:
        return ipaddress.ip_address(connection.client.host).is_loopback
    except (ValueError, AttributeError):
        return False


def same_origin(connection):
    origin = connection.headers.get("origin")
    scheme = "https" if connection.url.scheme in ("https", "wss") else "http"
    return origin == f"{scheme}://{connection.headers.get('host', '')}"


def public_event(event, role, student_id=None):
    """Default-deny new event types; never transmit teacher analytics to viewers."""
    kind = event.get("type")
    if kind in PUBLIC_EVENTS:
        return event
    if kind == "answer_received":
        return {k: event[k] for k in ("type", "count", "total") if k in event}
    if kind == "answer_feedback":
        return event if role == "student" and student_id == event.get("student_id") and student_id else None
    if kind == "engagement":
        rows = event.get("students", [])
        if role == "student":
            rows = [row for row in rows if student_id and row.get("student_id") == student_id]
        elif role != "projector":
            rows = []
        return {"type": "engagement", "class_score": event.get("class_score", 0),
                "class_attention": event.get("class_attention", 0),
                "students": [{k: row[k] for k in ("student_id", "name", "points") if k in row} for row in rows]}
    return None
