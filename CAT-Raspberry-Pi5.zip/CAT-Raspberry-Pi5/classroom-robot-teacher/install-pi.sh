#!/usr/bin/env bash
# Install this CAT project on Raspberry Pi OS without replacing the SD card.
set -euo pipefail
stage='checking prerequisites'
trap 'printf "\nInstallation stopped while %s (line %s).\nSend the error above; the app is not confirmed ready.\n" "$stage" "$LINENO" >&2' ERR
if [[ ${EUID} -ne 0 ]]; then
  printf '%s\n' 'Run: sudo bash install-pi.sh'
  exit 1
fi
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
if [[ ! -f /etc/debian_version ]] || ! command -v systemctl >/dev/null; then
  printf '%s\n' 'This installer is for Raspberry Pi OS with systemd.' >&2
  exit 1
fi
stage='installing Raspberry Pi OS packages'
apt-get update
apt-get install -y python3-venv python3-fastapi python3-uvicorn python3-websockets python3-qrcode python3-pypdf chromium xwayland wlr-randr
if ! id cat-teacher >/dev/null 2>&1; then
  useradd --system --home-dir /var/lib/cat-teacher --shell /usr/sbin/nologin cat-teacher
fi
install -d -o cat-teacher -g cat-teacher -m 0700 /var/lib/cat-teacher

stage='preserving existing data and application files'
if [[ -f /var/lib/cat-teacher/cat.db ]]; then
  /usr/bin/python3 - <<'PY'
from pathlib import Path
import sqlite3, time, os
source=Path('/var/lib/cat-teacher/cat.db')
target=source.with_name('cat-backup-'+time.strftime('%Y%m%d-%H%M%S')+'.db')
with sqlite3.connect(f'file:{source}?mode=ro',uri=True) as src, sqlite3.connect(target) as dst:
    src.backup(dst)
os.chmod(target,0o600)
print('Database backup:',target)
PY
elif [[ -f "$source_dir/data/cat.db" ]]; then
  /usr/bin/python3 - "$source_dir/data" <<'PY'
from pathlib import Path
import sqlite3, shutil, sys, os
source=Path(sys.argv[1]); target=Path('/var/lib/cat-teacher')
with sqlite3.connect(f'file:{source / "cat.db"}?mode=ro',uri=True) as src, sqlite3.connect(target/'cat.db') as dst:
    src.backup(dst)
for name in ('uploads','tts','lessons'):
    if (source/name).is_dir():
        shutil.copytree(source/name,target/name,dirs_exist_ok=True)
os.chmod(target/'cat.db',0o600)
print('Copied existing local CAT data into the service data directory.')
PY
  chown -R cat-teacher:cat-teacher /var/lib/cat-teacher
fi
if [[ -d /opt/cat-teacher/backend ]]; then
  backup_dir="/opt/cat-teacher-backup-$(date +%Y%m%d-%H%M%S)"
  install -d -m 0700 "$backup_dir"
  cp -a /opt/cat-teacher/backend /opt/cat-teacher/frontend "$backup_dir/"
fi
if systemctl cat cat-teacher.service >/dev/null 2>&1; then
  systemctl stop cat-teacher.service
fi
install -d -m 0755 /opt/cat-teacher /opt/cat-teacher/backend /opt/cat-teacher/frontend /opt/cat-teacher/pi
for folder in backend frontend pi; do
  cp -a "$source_dir/$folder/." "/opt/cat-teacher/$folder/"
done
install -m 0644 "$source_dir/PI5-START-HERE.md" /opt/cat-teacher/PI5-START-HERE.md
chown -R root:root /opt/cat-teacher
stage='preparing the Python environment'
python3 -m venv --system-site-packages /opt/cat-teacher/.venv
cd /opt/cat-teacher
/opt/cat-teacher/.venv/bin/python -c 'import fastapi, uvicorn, qrcode, pypdf, websockets'

stage='creating your private teacher account'
runuser -u cat-teacher -- env CAT_DATA_DIR=/var/lib/cat-teacher /opt/cat-teacher/.venv/bin/python -m backend.manage_teacher --ensure

stage='creating the CAT startup service'
if [[ ! -f /etc/cat-teacher.env ]]; then
  cat > /etc/cat-teacher.env <<'ENV'
# Optional: set CAT_PUBLIC_HOST to the Pi LAN address if QR auto-detection is wrong.
# CAT_PUBLIC_HOST=192.168.1.50
CAT_DATA_DIR=/var/lib/cat-teacher
CAT_ADMIN_LOOPBACK_ONLY=1
ENV
  chmod 0644 /etc/cat-teacher.env
fi
if [[ -f /etc/systemd/system/cat-teacher.service ]]; then
  cp -a /etc/systemd/system/cat-teacher.service "/etc/systemd/system/cat-teacher.service.backup-$(date +%Y%m%d-%H%M%S)"
fi
cat > /etc/systemd/system/cat-teacher.service <<'UNIT'
[Unit]
Description=Classroom-Aware Interactive Robot Teacher
After=network.target

[Service]
Type=simple
User=cat-teacher
Group=cat-teacher
WorkingDirectory=/opt/cat-teacher
EnvironmentFile=/etc/cat-teacher.env
Environment=PYTHONUNBUFFERED=1
ExecStart=/opt/cat-teacher/.venv/bin/python -m uvicorn backend.main:app --host 0.0.0.0 --port 8000 --workers 1 --no-proxy-headers
Restart=on-failure
RestartSec=3
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=strict
ReadWritePaths=/var/lib/cat-teacher
RestrictAddressFamilies=AF_INET AF_INET6 AF_UNIX

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 /etc/systemd/system/cat-teacher.service
systemctl daemon-reload
systemctl enable cat-teacher.service
systemctl reset-failed cat-teacher.service || true
systemctl restart cat-teacher.service

stage='checking that CAT actually responds'
ready=0
for attempt in {1..30}; do
  if systemctl is-active --quiet cat-teacher.service && /usr/bin/python3 -c '
import json,sys,urllib.request
try:
    with urllib.request.urlopen("http://127.0.0.1:8000/health",timeout=1) as response:
        data=json.load(response)
    sys.exit(0 if data.get("ready") is True and data.get("application")=="cat-teacher" else 1)
except Exception:
    sys.exit(1)
'; then ready=1; break; fi
  sleep 1
done
if [[ $ready -ne 1 ]]; then
  printf '\n%s\n' 'CAT did not become ready. Here is the startup error:' >&2
  systemctl status cat-teacher --no-pager -l || true
  journalctl -u cat-teacher -b -n 40 --no-pager || true
  exit 1
fi
printf '\n%s\n' 'CAT READY: http://127.0.0.1:8000/teacher'
printf '%s\n' 'Sign in as teacher using the passphrase you just created (or your existing account).'
printf '%s\n' 'Then run these in the Pi desktop terminal WITHOUT sudo:'
printf '%s\n' 'python3 /opt/cat-teacher/pi/setup-displays.py'
printf '%s\n' 'python3 /opt/cat-teacher/pi/launch-displays.py'
printf '%s\n' 'This protects the web controls; desktop/physical kiosk restrictions are a separate step.'
