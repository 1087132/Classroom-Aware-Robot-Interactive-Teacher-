#!/usr/bin/env python3
"""Two app windows under labwc/XWayland; no teacher session in these profiles."""
import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
import urllib.request


def outputs():
    result = subprocess.run(["wlr-randr", "--json"], check=True, text=True, capture_output=True)
    value = json.loads(result.stdout)
    if not isinstance(value, list):
        raise RuntimeError("Unexpected wlr-randr JSON format.")
    return value


def arrange(names):
    available = {output["name"]: output for output in outputs()}
    if any(name not in available for name in names):
        raise RuntimeError("Both configured HDMI screens must be connected and switched on.")
    first = available[names[0]]
    modes = first.get("modes", [])
    mode = next((m for m in modes if m.get("current")), None)
    if mode is None:
        mode = next((m for m in modes if m.get("preferred")), None)
    if not mode:
        raise RuntimeError("No usable mode was found for the first HDMI screen.")
    width = round(mode["width"] / first.get("scale", 1))
    transform = str(first.get("transform", "normal"))
    if transform in ("90", "270", "flipped-90", "flipped-270"):
        width = round(mode["height"] / first.get("scale", 1))
    subprocess.run(["wlr-randr", "--output", names[0], "--on", "--pos", "0,0",
                    "--output", names[1], "--on", "--pos", f"{width},0"], check=True)


def main():
    if os.geteuid() == 0:
        raise SystemExit("Run this as the desktop user, without sudo.")
    base = Path.home() / ".local/share/cat-teacher-displays"
    base.mkdir(parents=True, exist_ok=True, mode=0o700)
    lock = (base / "launcher.lock").open("w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit("CAT display launcher is already running.") from None
    names = json.loads((base / "outputs.json").read_text())
    chromium = shutil.which("chromium") or shutil.which("chromium-browser")
    if not chromium:
        raise SystemExit("Chromium is missing. Run install-pi.sh first.")
    ready = False
    for _ in range(30):
        try:
            with urllib.request.urlopen("http://127.0.0.1:8000/health", timeout=2) as response:
                health = json.load(response)
                ready = health.get("ready", False) and health.get("application") == "cat-teacher"
            if ready:
                arrange(names)
                break
        except Exception as error:
            print(f"Waiting for displays/server: {error}", flush=True)
        time.sleep(2)
    else:
        raise SystemExit("Display startup failed. Check both HDMI cables and the cat-teacher service.")
    children = {}
    stop = False

    def stopping(signum, frame):
        nonlocal stop
        stop = True

    signal.signal(signal.SIGTERM, stopping)
    signal.signal(signal.SIGINT, stopping)
    try:
        while not stop:
            for number in (1, 2):
                process = children.get(number)
                if process is None or process.poll() is not None:
                    args = [chromium, "--ozone-platform=x11", f"--class=cat-teacher-screen-{number}",
                            f"--user-data-dir={base / ('screen-' + str(number))}",
                            "--no-first-run", "--no-default-browser-check",
                            "--app=http://127.0.0.1:8000/" + ("robot" if number == 1 else "projector") + "?display=1"]
                    children[number] = subprocess.Popen(args, stdout=subprocess.DEVNULL)
                    time.sleep(1)
            time.sleep(2)
    finally:
        for process in children.values():
            if process.poll() is None:
                process.terminate()
        for process in children.values():
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
        lock.close()


if __name__ == "__main__":
    main()
